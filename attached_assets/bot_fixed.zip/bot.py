import os
import discord
from discord.ext import commands
from flask import Flask
from threading import Thread

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

TOKEN = os.environ.get("TOKEN") or os.getenv("TOKEN")
if not TOKEN:
    raise ValueError("No se encontró el TOKEN. Añádelo en las variables de entorno o en el archivo .env")

PORT = int(os.environ.get("PORT", 10000))

intents = discord.Intents.default()
bot = commands.Bot(command_prefix="!", intents=intents)

app = Flask(__name__)

@app.route("/")
def home():
    return "Bot activo 🚀"

def run_web():
    app.run(host="0.0.0.0", port=PORT)

Thread(target=run_web).start()

@bot.event
async def on_ready():
    print(f"Conectado como {bot.user}")

@bot.command()
async def ping(ctx):
    await ctx.send("🏓 Pong!")

bot.run(TOKEN)
